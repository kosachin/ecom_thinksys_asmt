import logo from "./logo.svg";
import "./App.css";
import { Link, Outlet, Route, Routes } from "react-router-dom";
import { Homepage } from "./components/homepage";

function App() {
  return (
    <div>
      <Link to="/">Home</Link>
      <Link to="/products">Products</Link>
      <div>
        <Outlet />
      </div>
    </div>
  );
}

export default App;
