import { Link } from "react-router-dom";
export const ProductBody = ({ classes, product }) => {
  return (
    <div className={classes.productContainer} key={product.id}>
      <div className={classes.productImgContainer}>
        <img src={product.image} />
      </div>
      <div className={classes.productDetailContainer}>
        <h5 className={classes.productTitle}>{product.title}</h5>
        <div className={classes.productControl}>
          <button>Add to cart</button>
          <Link style={{ textDecoration: "none" }} to={`/${product.id}`}>
            buy now
          </Link>
        </div>
      </div>
    </div>
  );
};
