import { Link } from "react-router-dom"

export const Homepage = () =>{
    return <div>
        <Link>Home</Link>
        <Link>Products</Link>
    </div>
}